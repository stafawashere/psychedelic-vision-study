Can a forest road turn into organized geometry and come back?
Mahfuj Mustafa | Research supplement

Start with docs/experiments/results.md for the reported arc and conditions.
The other three documents cover the design, the measurements and the activation study.
Commands in those documents run in the research checkout.

Each results/seed-N/frames directory holds the first render (00), simulated peak (13) and return (39). Figure 1 uses seed 0. For pixel error, convert both frames to floating-point RGB in [0,1], subtract frame 00 from the same seed, square, average over pixels and channels, and take the square root.

The eleven results/lattice-probe images are a separate diagnostic. injected_s0 through s7 are intact injections. asym_s3 through s5 are the phase-scrambled controls matched to seeds 3 through 5. In the research checkout, use form_constant_score on grayscale PNG values divided by 255. For intact injections report signed mirror averaged over all eight. For the matched comparison take absolute mirror before averaging each group of three. Use sample SD across seeds.
